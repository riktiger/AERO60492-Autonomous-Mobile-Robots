import pandas as pd

# Load files, ensuring trailing commas don't create unnamed empty columns
def load_and_clean(file):
    df = pd.read_csv(file, skipinitialspace=True)
    # Remove any columns that are entirely empty (common with trailing commas)
    df = df.dropna(axis=1, how='all')
    return df

df1 = load_and_clean('14320390.csv')
df2 = load_and_clean('14247379.csv')

# Ensure we are comparing the same shape
if df1.shape != df2.shape:
    print(f"Structural difference: File1 is {df1.shape}, File2 is {df2.shape}")

# Find differences
# align_axis=1 puts File1 and File2 values side-by-side for comparison
diff = df1.compare(df2, align_axis=1, keep_equal=False)

if diff.empty:
    print("No value differences found.")
else:
    print(f"Found {len(diff)} rows with differences:")
    print(diff)
    
    # Each 'pair' in the diff DataFrame represents 1 changed value
    # We count non-NaN values and divide by 2 to get the count of differences
    total_value_diffs = diff.notna().sum().sum() // 2
    print(f"\nTotal number of value differences: {total_value_diffs}")
