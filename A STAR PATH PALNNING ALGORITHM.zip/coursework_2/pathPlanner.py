# Import any libraries required
import random


# The main path planning function. Additional functions, classes, 
# variables, libraries, etc. can be added to the file, but this
# function must always be defined with these arguments and must 
# return an array ('list') of coordinates (col,row).
#DO NOT EDIT THIS FUNCTION DECLARATION
def do_a_star(grid, start, end, display_message):
    #EDIT ANYTHING BELOW HERE
    
    # Get the size of the grid
    COL = len(grid)
    ROW = len(grid[0])

    # Make a list of 10 random cell coordinates
    path = []
    for i in range(1,10):
        path.append((random.randint(0, COL-1),random.randint(0, ROW-1)))
        
    # Print an example debug message
    display_message("Created random path points")
    display_message("Start location is " + str(start))

    # Send the path points back to the gui to be displayed
    #FUNCTION MUST ALWAYS RETURN A LIST OF (col,row) COORDINATES
    return path

#end of file