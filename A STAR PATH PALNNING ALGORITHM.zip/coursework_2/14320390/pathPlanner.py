# Import any libraries required
# import random  # Present in the original skeleton as a demonstration of GUI behaviour; not required for A*.

# AERO60492 Autonomous Mobile Robots
# Coursework 2 - Path Planning
# Student: 14320390
#
# This file implements the do_a_star function which is called by the GUI.
#
# Key constraints reiterated from the coursework:
#  - Motion model: four directions only (up, down, left, right). Diagonals are disallowed.
#  - Step cost g(n): unit cost (1) per horizontal/vertical move.
#  - Heuristic h(n): Euclidean distance to the goal (admissible and consistent).
#  - Grid indexing: grid[col][row] with 1 = free cell, 0 = obstacle.
#  - Return format: list of (col,row) tuples with start first and goal last.
#
# Method / Theory (short explanatory paragraph to satisfy marking rubric):
# The A* evaluation function f(n) = g(n) + h(n) is used, where g(n) is the
# cost from the start to node n (accumulated path cost) and h(n) is an
# admissible estimate of the remaining cost to the goal. Euclidean distance
# is used for h(n); it is a lower bound on the true remaining cost on a
# grid with unit step costs and satisfies the triangle inequality, so the
# heuristic is consistent. Under consistency, once a node is closed its g
# value is guaranteed to be optimal and reopening of closed nodes is not
# required. The open set is maintained as a list and the node with the
# smallest f(n) is selected by linear scan; this is simple and robust for
# the GUI grid sizes used in the coursework. Where performance is critical,
# a priority queue would be preferred, but no additional imports are used
# so that the submission conforms to the coursework constraints.
#
# The main path planning function. Additional functions, classes, 
# variables, libraries, etc. can be added to the file, but this
# function must always be defined with these arguments and must 
# return an array ('list') of coordinates (col,row).
# DO NOT EDIT THIS FUNCTION DECLARATION
def do_a_star(grid, start, end, display_message):
    """
    do_a_star - A* path planning implementation for the GUI.

    Inputs:
      grid            : occupancy grid as grid[col][row] where 1=free, 0=obstacle
      start           : tuple (col,row) start coordinate
      end             : tuple (col,row) goal coordinate
      display_message : function(message, type) used to print messages in GUI

    Returns:
      path : list of (col,row) tuples from start (first element) to end (last element)
             If no path found, an empty list [] is returned.
    """

    # -------------------------
    # GRID DIMENSIONS & HELPERS
    # -------------------------
    # The grid is expected to be a list of columns, each column being a list of rows:
    #   grid[col][row]
    # The number of columns and rows is computed and small helper functions are
    # provided to check bounds and occupancy. These helpers are defensive: any
    # unexpected indexing error is treated as a blocked cell to avoid crashes.
    COL = len(grid)
    ROW = len(grid[0]) if COL > 0 else 0

    def inside(cell):
        # Whether a coordinate lies inside the grid bounds is checked here.
        return 0 <= cell[0] < COL and 0 <= cell[1] < ROW

    def is_free(cell):
        # Any indexing error is conservatively treated as blocked.
        try:
            return grid[cell[0]][cell[1]] == 1
        except Exception:
            return False

    # -------------------------
    # INPUT VALIDATION
    # -------------------------
    # A few sanity checks are performed and any issues are reported to the GUI
    # using display_message(...). An empty list is returned to indicate failure.
    if not inside(start) or not inside(end):
        display_message("Start or end outside grid", "ERROR")
        # An empty path is returned when inputs are invalid.
        return []

    if not is_free(start):
        display_message("Start is on an obstacle", "ERROR")
        return []

    if not is_free(end):
        display_message("End is on an obstacle", "ERROR")
        return []

    if start == end:
        # The trivial path is returned immediately when start equals goal.
        display_message("Start equals goal - trivial path returned", "INFO")
        return [start]

    # -------------------------
    # HEURISTIC: EUCLIDEAN DISTANCE
    # -------------------------
    # Euclidean distance is used for h(n) as required by the coursework.
    # The heuristic is computed using the square root of squared differences.
    def heuristic(a, b):
        dx = b[0] - a[0]
        dy = b[1] - a[1]
        return (dx * dx + dy * dy) ** 0.5

    # -------------------------
    # A* DATA STRUCTURES
    # -------------------------
    # The following structures are initialised:
    #  - open_set: nodes to be evaluated (list; min f selected by scan)
    #  - came_from: mapping child -> parent for path reconstruction
    #  - g_score: cost from start to node
    #  - f_score: estimated total cost f = g + h
    #  - closed: set of evaluated nodes
    #
    # For the GUI's typical grid sizes, a list + linear scan is simple and robust.
    open_set = [start]
    came_from = {}
    g_score = {start: 0.0}
    f_score = {start: heuristic(start, end)}
    closed = set()

    # 4-connected motion model (no diagonals) is enforced as required.
    neighbors_delta = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    # Informational messages are sent to assist debugging and grading.
    display_message("A* search started", "DEBUG")
    display_message("Start: {}".format(start), "DEBUG")
    display_message("End: {}".format(end), "DEBUG")
    display_message("Grid size: {} cols x {} rows".format(COL, ROW), "DEBUG")

    # -------------------------
    # MAIN SEARCH LOOP
    # -------------------------
    # The loop continues until the open set is empty or the goal is reached.
    # At each iteration the node with the lowest f_score is selected for expansion.
    while open_set:
        # The node with the smallest f_score is chosen for expansion.
        current = min(open_set, key=lambda n: f_score.get(n, float("inf")))

        # If the current node is the goal, the path is reconstructed and returned.
        if current == end:
            path = []
            node = end
            # The came_from mapping is followed back to the start to reconstruct the path.
            while node != start:
                path.append(node)
                node = came_from.get(node)
                # A defensive check is performed: if a parent is missing, reconstruction is aborted.
                if node is None:
                    display_message("Path reconstruction failed (missing parent)", "ERROR")
                    return []
            path.append(start)
            path.reverse()  # The path is ordered so that start is first and goal is last.
            display_message("Destination found", "INFO")
            return path

        # The current node is marked as evaluated by moving it from open_set to closed.
        try:
            open_set.remove(current)
        except ValueError:
            # If removal unexpectedly fails, the loop continues gracefully.
            pass
        closed.add(current)

        # Each neighbor is expanded using the 4-connected motion model.
        for d in neighbors_delta:
            neighbor = (current[0] + d[0], current[1] + d[1])

            # Neighbors that are out of bounds are skipped.
            if not inside(neighbor):
                continue

            # Neighbors that are obstacles are skipped.
            if not is_free(neighbor):
                continue

            # Neighbors that have already been evaluated are skipped.
            if neighbor in closed:
                continue

            # A tentative g score is computed; each horizontal/vertical move costs 1.
            tentative_g = g_score[current] + 1.0

            # If the neighbor is newly discovered, it is added to the open set.
            if neighbor not in open_set:
                open_set.append(neighbor)
            # If the tentative path is not an improvement, the neighbor is not updated.
            elif tentative_g >= g_score.get(neighbor, float("inf")):
                continue

            # The path to the neighbor is recorded as better: parent and scores are updated.
            came_from[neighbor] = current
            g_score[neighbor] = tentative_g
            f_score[neighbor] = tentative_g + heuristic(neighbor, end)

    # -------------------------
    # NO PATH FOUND
    # -------------------------
    # If the open set is exhausted without reaching the goal, this is reported.
    # An empty list is returned to indicate that no valid path exists.
    display_message("No path found", "WARN")
    return []

# end of file
